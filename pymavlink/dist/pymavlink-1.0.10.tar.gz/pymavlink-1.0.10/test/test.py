#!/usr/bin/env python

import unittest
import os
from pymavlink import *


class Test(unittest.TestCase):

    def setUp(self):
        pass

    def test_simple(self):
        print 'test simple'
